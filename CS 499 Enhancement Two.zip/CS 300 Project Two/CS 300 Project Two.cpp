//============================================================================
// Name        : CS 300 Project Two.cpp
// Author      : Tyler Mort
// Version     : 1.0
// Copyright   : Copyright � 2017 SNHU COCE
// Description : Load course info from a CSV and store as objects in a bst to display
//============================================================================

#include <iostream>
#include <fstream>
#include <sstream>
#include <time.h>
#include <vector>

using namespace std;

//============================================================================
// Global definitions visible to all methods and classes
//============================================================================

// define a structure to hold course information
struct Course {
    string courseCode; // unique identifier
    string courseName;
    string courseNumber;
    vector<string> prereq;
    Course() {};
};

// Internal structure for tree node
struct Node {
    Course course;
    Node* left;
    Node* right;

    // default constructor
    Node() {
        left = nullptr;
        right = nullptr;
    }

    // initialize with a course
    Node(Course aCourse) :
        Node() {
        this->course = aCourse;
    }
};

// forward declarations
void displayCourse(Course course);
void displayCourses(Course course);

//============================================================================
// Binary Search Tree class definition
//============================================================================

/**
 * Define a class containing data members and methods to
 * implement a binary search tree
 */
class BinarySearchTree {

private:
    Node* root;

    void addNode(Node* node, Course course);
    void inOrder(Node* node);
    Node* removeNode(Node* node, string courseCode);

public:
    BinarySearchTree();
    virtual ~BinarySearchTree();
    void InOrder();
    void Insert(Course course);
    void Remove(string courseCode);
    Course Search(string courseCode);
    Course quickSearch(string courseNumber);
};

//method to skip unwanted bytes at beginning of file
void skipBOM(istream& fin) {
    char testInput[3] = { 0 };
    //Read first characters from file
    fin.read(testInput, 3);
    //if the characters match the unwanted byte markers, skip them
    if ((unsigned char)testInput[0] == 0xEF && (unsigned char)testInput[1] == 0xBB && (unsigned char)testInput[2] == 0xBF) {
        return;
    }
    fin.seekg(0);
}
/**
 * Default constructor
 */
BinarySearchTree::BinarySearchTree() {
    //set root equal to nullptr
    root = nullptr;
}

/**
 * Destructor
 */
BinarySearchTree::~BinarySearchTree() {
    // recurse from root deleting every node
}

/**
 * Traverse the tree in order
 */
void BinarySearchTree::InOrder() {
    // call inOrder fuction and pass root 
    this->inOrder(root);
}



/**
 * Insert a course
 */
void BinarySearchTree::Insert(Course course) {
    if (root == nullptr) {
        // root is equal to new node course
        root = new Node(course);
    }
    else {
        // add Node root and course
        this->addNode(root, course);
    }
}

/**
 * Remove a course
 */
void BinarySearchTree::Remove(string courseCode) {
    // remove node root courseCode
    this->removeNode(root, courseCode);
}

/**
 * Remove a course from a node
 *
 * @param node Current node in tree
 * @param course Course to be removed
 */
Node* BinarySearchTree::removeNode(Node* current, string courseCode) {
    //If the node is null return node value and exit early
    if (current == nullptr) {
        return current;
    }
    //If current node is greater than intended node, move left
    if (courseCode.compare(current->course.courseCode) < 0) {
        current->left = removeNode(current->left, courseCode);
    }
    //If current node is less than intended node, move right
    else if (courseCode.compare(current->course.courseCode) > 0) {
        current->right = removeNode(current->right, courseCode);
    }
    else {
        //If there are no children, delete the node
        if (current->left == nullptr && current->right == nullptr) {
            delete current;
            current = nullptr;
        }
        //If there is only a right child, delete the node
        else if (current->left == nullptr && current->right != nullptr) {
            current = current->right;
            current->right = nullptr;
        }
        //If there is only a left child, delete the node
        else if (current->left != nullptr && current->right == nullptr) {
            current = current->left;
            current->left = nullptr;
        }
        else {
            //Find successor node
            Node* temp = current->right;
            //Move to leftmost node
            while (temp->left != nullptr) {
                temp = temp->left;
            }
            //Set current to successor value
            current->course = temp->course;
            //Recursively pass argument to remove right side
            current->right = removeNode(current->right, temp->course.courseCode);
        }
    }
    return current;
}
/**
 * Search for a course
 */
Course BinarySearchTree::Search(string courseCode) {
    // set current node equal to root
    Node* current = root;

    // keep looping downwards until bottom reached or matching courseCode found
    while (current != nullptr) {
        // if match found
        if (current->course.courseCode.compare(courseCode) == 0) {
            return current->course;
        }
        // if course is smaller than current node then traverse left
        if (current->course.courseCode.compare(courseCode) > 0) {
            current = current->left;
        }
        // else larger so traverse right
        else {
            current = current->right;
        }
    }
    Course course;
    return course;
}

/**
 * Search for a course
 */
Course BinarySearchTree::quickSearch(string courseNumber) {
    // set current node equal to root
    Node* current = root;

    // keep looping downwards until bottom reached or matching courseCode found
    while (current != nullptr) {
        // if match found
        if (current->course.courseNumber.compare(courseNumber) == 0) {
            return current->course;
        }
        // if course is smaller than current node then traverse left
        if (current->course.courseNumber.compare(courseNumber) > 0) {
            current = current->left;
        }
        // else larger so traverse right
        else {
            current = current->right;
        }
    }
    Course course;
    return course;
}



/**
 * Add a course to some node (recursive)
 *
 * @param node Current node in tree
 * @param course Course to be added
 */
void BinarySearchTree::addNode(Node* node, Course course) {
    // if node is larger then add to left
    if (node->course.courseCode.compare(course.courseCode) > 0) {
        // if no left node
        if (node->left == nullptr) {
            // this node becomes left
            node->left = new Node(course);
        }
        else {
            //recurse down the left side
            this->addNode(node->left, course);
        }
    }
    else {
        // if no right node
        if (node->right == nullptr) {
            // this node becomes right
            node->right = new Node(course);
        }
        else {
            //recurse down the right side
            this->addNode(node->right, course);
        }
    }
}

void BinarySearchTree::inOrder(Node* node) {
    //if node is not equal to null ptr
    if (node != nullptr) {
        //InOrder left
        inOrder(node->left);
        //output course info
        displayCourses(node->course);
        //InOder right
        inOrder(node->right);
    }
}


//============================================================================
// Static methods used for testing
//============================================================================

//Print individual course anprerequisites
void displayCourse(Course course) {
    cout << course.courseCode << ": " << course.courseName << endl;
    cout << "Prerequisites: ";
    //Store size of prerequisite vector
    int size = course.prereq.size();
    if (size > 0) {
        //Iterate through all elements of the vector
        for (auto elem : course.prereq) {
            if (size > 1) {
                //Print elements and decrease remaining size
                cout << elem << ", ";
                size--;
            }
            else {
                //Prnt last element without comma
                cout << elem << endl;
            }
        }
    }
    else {
        //Print message if nothing is found
        cout << "None" << endl;
    }
    return;
}

/**
 * Display the course information to the console (std::out)
 *
 * @param course struct containing the course info
 */

 //Prints all courses in alphabetical order
void displayCourses(Course course) {
    cout << course.courseCode << ": " << course.courseName << endl;
    return;
}



/**
 * Load a CSV file containing courses into a container
 *
 * @param csvPath the path to the CSV file to load
 * @return a container holding all the courses read
 */
void loadCourses(string csvPath, BinarySearchTree* bst) {
    cout << "Loading CSV file " << csvPath << endl;
        //Open file
        ifstream fin(csvPath);
        //Send message if file cannot be loaded
        if (!fin.is_open()) {
            cout << "Failed to Load CSV File! Please Check File Name and Try Again!" << endl;
        }else{
            //Declare initial variables
            string courseCode, courseName, courseNumber;
            vector<string> prereq;
            string line;
            string delim = ",";
            //Call method to remove unwanted characters
            skipBOM(fin);

            //While there are still lines to read
            while (getline(fin, line)) {
                if (!line.empty()) {
                //Store first item as course alpha numerical
                courseCode = line.substr(0, line.find(delim));
                //Extract course number only
                courseNumber = courseCode;
                courseNumber.erase(0, 4);
                //Remove the captured items
                line.erase(0, line.find(delim) + delim.length());
                //Store next item as course name
                courseName = line.substr(0, line.find(','));
                //Remove the captured items
                line.erase(0, line.find(delim) + delim.length());
                //While items remain, add them to prerequisites
                while (line.length() > 0) {
                    prereq.push_back(line.substr(0, line.find(',')));
                    line.erase(0, line.find(delim) + delim.length());
                }
                //Create a course object and add captured values
                Course course;
                course.courseCode = courseCode;
                course.courseNumber = courseNumber;
                course.courseName = courseName;
                course.prereq = prereq;
                //Insert courses to search tree
                bst->Insert(course);
                //Remove all items from the vector
                prereq.clear();
                }
                
            }
            
        }
    
}

/**
 * The one and only main() method
 */
int main(int argc, char* argv[]) {

    // process command line arguments
    string csvPath, courseCode, courseNumber;

    // Define a timer variable
    clock_t ticks;

    // Define a binary search tree to hold all courses
    BinarySearchTree* bst;
    bst = new BinarySearchTree();
    Course course;

    int choice = 0;
    while (choice != 9) {
        cout << "Menu:" << endl;
        cout << "  1. Load Courses" << endl;
        cout << "  2. Print All Courses" << endl;
        cout << "  3. Search by Course Code" << endl;
        cout << "  4. Quick Search by Course Number" << endl;
        cout << "  9. Exit" << endl;
        cout << "What would you like to do? ";
        cin >> choice;

        switch (choice) {

        case 1:
            //Prompt for file to load
            cout << "Please enter the file name and extension you would like to load" << endl;
            cin >> csvPath;
            
            // Initialize a timer variable before loading courses
            ticks = clock();

            // Complete the method call to load the courses
            loadCourses(csvPath, bst);

            // Calculate elapsed time and display result
            ticks = clock() - ticks; // current clock ticks minus starting clock ticks
            cout << "time: " << ticks << " clock ticks" << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;
            break;

        case 2:
            //Call to print tree in order
            bst->InOrder();
            break;

        case 3:
            ticks = clock();

            //Prompt user for course to search
            cout << "Please enter a course code to search for" << endl;
            cin >> courseCode;
            //Find prompted course
            course = bst->Search(courseCode);

            ticks = clock() - ticks; // current clock ticks minus starting clock ticks

            //If course has a value, return it
            if (!course.courseCode.empty()) {
                displayCourse(course);
            }
            else {
                //If course is empty, return not found
                cout << "Course: " << courseCode << " not found." << endl;
            }

            cout << "time: " << ticks << " clock ticks" << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;

            break;

        case 4:
            ticks = clock();

            //Prompt user for course to search
            cout << "Please enter a course number to search for" << endl;
            cin >> courseNumber;
            //Find prompted course
            course = bst->quickSearch(courseNumber);

            ticks = clock() - ticks; // current clock ticks minus starting clock ticks

            //If course has a value, return it
            if (!course.courseNumber.empty()) {
                displayCourse(course);
            }
            else {
                //If course is empty, return not found
                cout << "Course: " << courseNumber << " not found." << endl;
            }

            cout << "time: " << ticks << " clock ticks" << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;

            break;

        //Skip case if exit command is selected
        case 9:
            break;

         //Inform user if choice is not valid
        default:
            cout << choice << " is not a valid option. Please select another option" << endl;
            break;

        }
    }

    cout << "Thank you for using the course planner!" << endl;

    return 0;
}
