from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelterCRUD(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password, host, port, database, collection):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        USER = username
        PASS = password
        HOST = host
        PORT = port
        DB = database
        COL = collection
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER, PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
    

# Create method to implement the C in CRUD.
    def create(self, data):
        #Insert a document into DB
        try:
            result = self.collection.insert_one(data)
            return True if result.inserted_id else False
        except Exception as e:
            print(f"Error inserting the document: {e}")
            return False

# Read method to implement the R in CRUD.
    def read(self, searchData):
        # Search by given query in database
        try:
            cursor = self.collection.find(searchData)
            return list(cursor) #Convert cursor to list of documnts
        except Exception as e:
            print(f"Error querying documents: {e}")
            return []
#Get specified query        
    def getRecord(self, criteria):
        if criteria:
            _data = self.dataBase.animals.find(criteria, {'_id' : 0})
                                 
        else:
            _data = self.dataBase.animals.find({},{'_id' : 0})
                                  
        return _data
#Update method for U in CRUD.
    def update(self, query, new_data):
      #Update document in DB
      try:
        result = self.collection.update_many(query, {'$set': new_data})
        return result.modified_count
      except Exception as e:
        print(f"An error ocurred: {e}")
        return 0
#Delete method for D in CRUD.
    def delete(self, query):
      try:
        result = self.collection.delete_many(query)
        return result.deleted.count
      except Exception as e:
        print(f"An error ocurred: {e}")
        return 0
